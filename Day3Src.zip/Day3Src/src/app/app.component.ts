import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:'<h1>{{title}}</h1>',
  //template:`<h1>
  //{{title}}
  //</h1>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularApp2021';
  person={id:123,fname:"Swati",lname:"Bhirud"};
  fullname;
  flag=true;

  show=true;
  
  colors=["Red","Green","Blue","Orange"];
  
  fullName(){
    this.fullname=this.person.fname +this.person.lname;
    console.log(this.fullname);
  }
  
}
